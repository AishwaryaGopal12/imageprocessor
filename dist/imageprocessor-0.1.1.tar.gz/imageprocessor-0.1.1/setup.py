# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['imageprocessor']

package_data = \
{'': ['*']}

install_requires = \
['matplotlib>=3.3.4,<4.0.0',
 'numpy>=1.20.1,<2.0.0',
 'opencv-python>=4.5.1,<5.0.0',
 'python-semantic-release>=7.15.0,<8.0.0',
 'scikit-image>=0.18.1,<0.19.0']

setup_kwargs = {
    'name': 'imageprocessor',
    'version': '0.1.1',
    'description': 'Python packages that can provide some functionalities to modify an image',
    'long_description': None,
    'author': 'Rui, Mo, Joshua, Aishwarya',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
